import { Component, OnInit, DoCheck } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-type',
  templateUrl: './type.component.html',
  styleUrls: ['./type.component.scss']
})
export class TypeComponent implements OnInit, DoCheck {
  isChildRouteLoaded = false;
  usr:any;
  constructor(public fb: FormBuilder , private router: ActivatedRoute) { }

  ngOnInit() {
    
  }

  ngDoCheck() {
    this.router.children.length !== 0 ? this.isChildRouteLoaded = true : this.isChildRouteLoaded = false;
  }
  ok()
  {
    this.usr = "['/type/reg',('bhanu')]";
  }
}
