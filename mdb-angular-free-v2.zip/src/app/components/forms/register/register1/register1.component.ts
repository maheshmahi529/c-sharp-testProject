import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RegisterService } from '../../../../app/service/register.service';
@Component({
  selector: 'app-register1',
  templateUrl: './register1.component.html',
  styleUrls: ['./register1.component.scss'],
  providers: [RegisterService]
})
export class Register1Component implements OnInit {

  cardForm: FormGroup;
  usertype: any;
  
  constructor(public fb: FormBuilder, public route: ActivatedRoute, private userservice: RegisterService) {
    this.usertype = this.route.snapshot.paramMap.get('ty');
    console.log(this.usertype);
    this.cardForm = fb.group({
      Name: ['', Validators.required],
      Email: ['', [Validators.email, Validators.required]],
      Mobile: ['', Validators.required],
      Password: ['', Validators.required]
    });


  }
  ngOnInit() {

  }
  submitForm(data) {
    console.log(data);
    console.log(JSON.stringify(data));
    this.userservice.signupUser(data).subscribe(res => {
      console.log('This is Data' + JSON.stringify(res));
     
   });
  }




}
