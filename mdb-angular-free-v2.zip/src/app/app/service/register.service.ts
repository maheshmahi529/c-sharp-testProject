import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch'; 
import 'rxjs/Rx';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http: Http) { }
  signupUser(data:any){ 
    //console.log("this" + JSON.stringify(data));
     return this.http.post('http://localhost/job_site7/api/user/post', data)  
     .map((response: Response) =>response.json())      
  }
}
