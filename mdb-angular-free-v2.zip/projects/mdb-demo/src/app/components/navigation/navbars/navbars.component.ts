import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbars',
  templateUrl: './navbars.component.html',
  styleUrls: ['./navbars.component.scss']
})
export class NavbarsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
